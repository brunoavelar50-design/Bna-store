# BNA Store

Primeira versão da interface da loja.

## Arquivos
- index.html — estrutura da loja
- style.css — visual/responsividade
- script.js — produtos, filtros, busca e carrinho

## Como testar
Abra o arquivo `index.html` no navegador.

Os produtos atuais são demonstrativos. No próximo passo, eles podem ser substituídos pelos produtos reais, preços e imagens da BNA Store.
